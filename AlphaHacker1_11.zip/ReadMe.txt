Thanks for downloading AlphaHacker 1.06!

INSTRUCTIONS
------------

Please look at help.txt for help on playing the game.

For support, please go to:

http://www.alpharez.com/

REGISTRATION
------------

Your $9.95 will entitle you to free updates for life.  I'll keep
your email address on file and send updates as they are available.

If you have any other comments, please send them to:

steve@alpharez.com

DISCLAIMER
----------

There are no guarantees or warranties associated with AlphaHacker 1.06.  